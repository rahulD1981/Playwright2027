import { test, expect } from "@playwright/test";

import { TestConfig } from '../TestConfig';
import { POManager } from "../pages/POManager";

const rawData = JSON.parse(JSON.stringify(require("../TestData/LoginPageTestData.json")));
const dataSet = Array.isArray(rawData) ? rawData : [rawData]; //convreted data set to array if not an array

let pOManager: POManager;

   
  test.beforeEach(async ({ page }) => {
     //page objects from po manager
    pOManager = new POManager(page);
 
const config = new TestConfig();
    await page.goto(config.appUrl); // Navigate to application url
 });

test('User can sign up with a new account', async ({ page }) => {
    pOManager.loginPage.login("rahuldhoke", "rahuldhoke")
   await page.waitForTimeout(2000);
   
       await pOManager.homePage.addProductToCart("Nexus 6");
       console.log("Nexus 6");
       await page.waitForTimeout(1000);
    
});


